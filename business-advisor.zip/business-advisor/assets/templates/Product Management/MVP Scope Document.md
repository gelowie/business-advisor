# MVP Scope Document

## Summary

Scopes a minimum viable product around the single riskiest assumption, cutting everything that doesn't test it.

## Inputs

- **Product idea** — [what it is]
- **Riskiest assumption** — [the thing that, if false, kills the idea]
- **Target user for the test** — [a specific segment, not "everyone"]
- **Resources and timeline** — [team size, budget, time available to build]

## Deliverable

1. The riskiest assumption restated as a testable hypothesis
2. The minimum feature set that tests that hypothesis, and nothing more
3. What's being cut for this version, and why it's safe to cut
4. How success or failure will be measured — a specific number or behavior, not a feeling
5. A timeline to get this in front of real users

## Requirements

- Every included feature must trace directly back to testing the hypothesis
- No polish, edge-case handling, or "nice to have" features at this stage
- The success metric must be observable and specific, not "see how it goes"
- If the described scope still doesn't fit the stated resources or timeline, cut further and say so

## Related templates

- [Roadmap Prioritization Worksheet](Roadmap Prioritization Worksheet.md)
- [Pricing Strategy Builder](../Finance and Fundraising/Pricing Strategy Builder.md)
