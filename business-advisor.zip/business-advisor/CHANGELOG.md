# Changelog

## [1.0.0] - 2026-09

### Added
- `SKILL.md` business advisor covering eight domains and four business types.
- Nine reference files (eight domains plus business types) and 20 fill-in templates in eight domain folders.
- MIT `LICENSE`.
